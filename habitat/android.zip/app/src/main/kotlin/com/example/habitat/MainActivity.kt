package com.status200.habitat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
